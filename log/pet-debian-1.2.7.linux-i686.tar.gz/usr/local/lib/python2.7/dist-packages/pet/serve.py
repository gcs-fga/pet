def pet_serve():
    print("Urruw")
